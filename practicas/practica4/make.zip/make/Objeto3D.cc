//**************************************************************************
// Práctica 4
//
//  Emilio Jose Ochando Pantigas
//
//  3ºC grupo C2
//**************************************************************************

//#include <GL/gl.h>
//#include <GL/glut.h>
//#include <OpenGL/OpenGL.h>        //macOX
//#include <GLUT/glut.h>            //macOX
#include <string>
#include "Objeto3D.h"
#include <stdio.h>
#include <math.h>

#include <vector>



void Objeto3D::drawAll(){



    glPolygonMode(GL_FRONT, GL_POINT);
    glPointSize(10);

    glEnable(GL_CULL_FACE);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_COLOR_ARRAY);
    glColorPointer(3, GL_FLOAT, 0, &colores[0]);
    glVertexPointer(3, GL_FLOAT, 0, &vertices[0]);
    glNormalPointer( GL_FLOAT, 0, &normalesVertices[0]);
    glDrawElements( GL_POINTS, caras.size(), GL_UNSIGNED_INT, &caras[0]);
    

    glPolygonMode(GL_FRONT, GL_LINE);
    glColorPointer(3, GL_FLOAT, 0, &colores[0]-1);
    
    glDrawElements( GL_TRIANGLES, caras.size(), GL_UNSIGNED_INT, &caras[0]);

    glPolygonMode(GL_FRONT, GL_FILL);
    glColorPointer(3, GL_FLOAT, 0, &colores[0]-2);

    glDrawElements( GL_TRIANGLES, caras.size(), GL_UNSIGNED_INT, &caras[0]);
    glDisable(GL_CULL_FACE);
    
}




//**************************************************************************
// Funcion para dibujar el objeto en todos sus modos(punto, linea, solido)
//***************************************************************************
void Objeto3D::drawMode( GLenum tipo){
    



    glPolygonMode(GL_FRONT, tipo);
    glPointSize(10);
    glEnable(GL_CULL_FACE);
    glEnableClientState(GL_VERTEX_ARRAY);
    glShadeModel(GL_SMOOTH);
    glEnable(GL_NORMALIZE);
    glEnable(GL_TEXTURE_2D);
    //glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_COLOR_ARRAY);
    glColorPointer(3, GL_FLOAT, 0, &colores[0]);
    glVertexPointer(3, GL_FLOAT, 0, &vertices[0]);
    glNormalPointer( GL_FLOAT, 0, &normalesVertices[0]);
    glDrawElements( GL_TRIANGLES, caras.size(), GL_UNSIGNED_INT, &caras[0]);
    glDisable(GL_CULL_FACE);
    glDisable(GL_NORMALIZE);
}



//**************************************************************************
// Funcion para dibujar el objeto en modo ajedrez
//***************************************************************************

void Objeto3D::drawChess(){
    std::vector<unsigned int>carasPar;
    std::vector<unsigned int>carasImpar;
    std::vector<float>cNegativos;
    std::vector<float>cColores;

    carasPar.resize(0);
    carasImpar.resize(0);
    cNegativos.resize(0);
    
    
    //Funcion para crear los negativos de los colores
    for (int i = 0; i <= this->colores.size(); i += 3){
        
        
        int r = 0, g = 0, b = 0;
        r = 255 - colores[i];
        g = 255 - colores[i + 1];
        b = 255 - colores[i + 2];
        
        cNegativos.push_back(r);
        cNegativos.push_back(g);
        cNegativos.push_back(b);
    }
    
    for (int i = 0; i <= caras.size(); i += 3){
        if (i%2 != 0){
            carasImpar.push_back(caras[i]);
            carasImpar.push_back(caras[i + 1]);
            carasImpar.push_back(caras[i + 2]);
        } 
    }
    
    
    glPolygonMode(GL_FRONT, GL_FILL);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_COLOR_ARRAY);
    

    glColorPointer(3, GL_FLOAT, 0, &colores[0]);
    glDrawElements( GL_TRIANGLES, carasImpar.size(), GL_UNSIGNED_INT, &carasImpar[0]);
    
    
    glColorPointer(3, GL_FLOAT, 0, &cNegativos[0]);
    glDrawElements( GL_TRIANGLES, caras.size(), GL_UNSIGNED_INT, &caras[0]);

    glDisableClientState(GL_COLOR_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
}

//**************************************************************************
// Funcion para modelar el dibujado del objeto segun la tecla pulsada
//***************************************************************************

void Objeto3D::draw(char tecla){
        switch(tecla){
            case 'P':this->drawMode(GL_POINT);break;
            case 'L':this->drawMode(GL_LINE);break;
            case 'F':this->drawMode(GL_FILL);break;
            case 'C':this->drawChess();break;
            case 'A':this->drawAll();break;
            
    }
}

void Objeto3D::calcularNormalesCaras(){
    // Calculamos las normales de las caras
    int caraA=0;
    int caraB=0;
    int caraC=0;
    for(int i = 0; i < caras.size()-2; i+=3){
        std::vector<float>A ,B, C;
        //_vertex3f A, B, C;
        caraA=caras[i]*3;
        A.push_back(vertices[caraA]);
        A.push_back(vertices[caraA+1]);
        A.push_back(vertices[caraA+2]);
        caraB=caras[i+1]*3;
        B.push_back(vertices[caraB]);
        B.push_back(vertices[caraB+1]);
        B.push_back(vertices[caraB+2]);
        caraC=caras[i+2]+3;
        C.push_back(vertices[caraC]);
        C.push_back(vertices[caraC+1]);
        C.push_back(vertices[caraC+2]);


        std::vector<float> ab, bc, normal;

        ab.push_back(B[0]-A[0]);
        ab.push_back(B[1]-A[1]);
        ab.push_back(B[2]-A[2]);

        bc.push_back(C[0] - A[0]);
        bc.push_back(C[1] - A[1]);
        bc.push_back(C[2] - A[2]);

        // Calculamos el producto vectorial 
        normal.push_back(ab[1] * bc[2] - ab[2] * bc[1]);
        normal.push_back(-(ab[2] * bc[0] - ab[0] * bc[2]));
        normal.push_back(ab[0] * bc[1] - ab[1] * bc[0]);

        // normalizar
        float modulo=sqrt(normal[0]*normal[0]+normal[1]*normal[1]+normal[2]*normal[2]);
       
        normalesCaras.push_back(normal[0]/modulo);
        normalesCaras.push_back(normal[1]/modulo);
        normalesCaras.push_back(normal[2]/modulo);

    }
}


void Objeto3D::calcularNormalesVertices(){

    // Recorremos los vertices
    for(int i = 0; i < vertices.size()-2; i+=3){
        int cara = i/3;
        
        std::vector<float>verticesActual;
        verticesActual.push_back(vertices[i]);
        verticesActual.push_back(vertices[i+1]);
        verticesActual.push_back(vertices[i+2]);
        std::vector<float>normal;

        // Recorremos las caras
        for(int h = 0; h < caras.size(); h++)
        {
            // Comprobamos si el vertice esta en otra cara (por la posicion)
            if (verticesActual[i] == vertices[cara] || verticesActual[i+1] == vertices[cara+1] || verticesActual[i+2] == vertices[cara+2]){
                
                normal.push_back(normal[0]+normalesCaras[cara]);
                normal.push_back(normal[1]+normalesCaras[cara+1]);
                normal.push_back(normal[2]+normalesCaras[cara+2]);
            }

        }

        //normalizamos
        float modulo=sqrt(normal[0]*normal[0]+normal[1]*normal[1]+normal[2]*normal[2]);

        normalesVertices.push_back(normal[0]/modulo);
        normalesVertices.push_back(normal[1]/modulo);
        normalesVertices.push_back(normal[2]/modulo);
        normal.resize(0);
    }
}

